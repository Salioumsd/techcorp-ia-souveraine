# 📊 Livrables DATA & PIPELINES

## 1. Préparation et Nettoyage du Dataset
*   **Source :** `huggingface.co/datasets/ruslanmv/ai-medical-chatbot`
*   **Transformation :** Extraction des features brutes `Patient` et `Doctor` et sérialisation au format d'instruction d'entraînement : `<s>### Human: [Prompt] ### Assistant: [Réponse]</s>`.

## 2. Rapport de Qualité des Données
*   **Volumétrie du PoC :** Échantillonnage contrôlé à 100 observations hautement qualitatives pour le sprint.
*   **Alignement Contextuel :** Application d'une troncature stricte à une longueur maximale de `256 tokens` (via le Tokenizer de Phi-3.5) afin d'uniformiser la taille des lots et de prévenir les anomalies de tenseurs vides.
*   **Nettoyage :** Suppression des caractères de contrôle et des dialogues incomplets.
