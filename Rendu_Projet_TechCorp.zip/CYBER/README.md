# 🛡️ Livrables CYBER-SÉCURITÉ & ROBUSTESSE

## 1. Tests de Robustesse & Guardrails
*   **Sécurité logique :** Injection d'un bloc système hermétique en amont de l'interface pour filtrer les entrées utilisateur, bloquer les attaques par injection de prompts (*jailbreak*) et interdire au modèle de traiter des sujets en dehors du périmètre validé.

## 2. Post-Mortem : Gestion de Crise Matérielle (CUDA OOM)
Lors de la phase expérimentale, une panne critique de dépassement de capacité mémoire GPU (`OutOfMemoryError`) a été détectée sur le matériel d'accueil.
*   **Analyse :** Saturation des 14.5 Go de VRAM lors de l'allocation en précision native.
*   **Contre-mesure cyber/infra :** Implémentation immédiate de la **Quantification NF4 (4-bit)** via la suite logicielle `BitsAndBytes`. Cette compression sécurisée a permis de réduire l'occupation de la mémoire VRAM sous la barre des 4 Go sans dégrader les vecteurs de raisonnement fondamentaux, garantissant la résilience du service.
