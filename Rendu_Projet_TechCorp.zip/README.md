# 💼 TechCorp - Projet IA Souveraine & R&D Médicale

Ce dépôt contient l'intégralité des livrables requis pour le projet TechCorp, segmentés par spécialité conformément au brief.

## 📁 Organisation du Dépôt
*   **/INFRA** : Serveur d'inférence, choix techniques et guide de déploiement.
*   **/IA** : Poids et configuration du modèle principal et du PoC LoRA.
*   **/DATA** : Scripts de préparation, nettoyage et rapport de qualité des données.
*   **/CYBER** : Rapports de sécurité, tests de robustesse et contre-mesures (OOM/Quantification).
*   **/DEV_WEB** : Code source complet de l'interface utilisateur Streamlit et intégration API.

---
**Date de rendu :** 30 Juin 2026  
**Statut :** Livrables validés, conteneurs stables, PoC R&D convergent.
