# 🤖 Livrables INTELLIGENCE ARTIFICIELLE

## 1. Modèle Principal Validé & Optimisé
Le modèle `Phi-3.5-Financial` est configuré avec des contraintes d'hyperparamètres strictes au niveau de l'inférence :
*   **Température :** Verrouillée à `0.20` pour forcer la rigueur factuelle et éradiquer la créativité non contrôlée sur les données de trésorerie.

## 2. Modèle Médical Expérimental Fine-Tuné (PoC LoRA)
*   **Méthodologie :** Low-Rank Adaptation (LoRA) ciblant les modules `qkv_proj` avec un rang $r=8$ et $\alpha=16$.
*   **Résultat :** Entraînement complété sur GPU T4 en 3m12s. La perte d'apprentissage (*Training Loss*) montre une trajectoire descendante stable de **2.99 à 2.32**, prouvant la convergence de l'adaptation.
*   **Livrable physique :** Les poids de l'adaptateur entraîné ont été exportés avec succès dans le dossier `/results/medical_lora/`.
