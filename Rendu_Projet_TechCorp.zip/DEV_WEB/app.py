import streamlit as st
import requests
import json

st.set_page_config(page_title="TechCorp AI", layout="wide")
st.sidebar.title("Paramètres Système")
temp = st.sidebar.slider("Température (Rigueur vs Créativité)", 0.0, 1.0, 0.20)

st.title("💼 TechCorp AI - Assistant Financier")
st.sidebar.info("🔒 Sécurité : Toutes les requêtes sont auditées en temps réel conformément aux protocoles TechCorp.")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if prompt := st.chat_input("Posez votre question financière..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
        
    # Simulation appel API locale Ollama
    with st.chat_message("assistant"):
        st.write("Exécution locale sur serveur d'inférence souverain...")
