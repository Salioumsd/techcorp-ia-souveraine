# 💻 Livrables DÉVELOPPEMENT WEB

## 1. Interface Web Complète & Fonctionnelle
*   **Framework :** Développé sous Streamlit (Python), offrant un panneau de contrôle pour la température, des indicateurs de sécurité audités en direct et une persistance locale de la session de chat.

## 2. Intégration API Temps Réel
Connexion établie nativement avec le serveur d'inférence Docker. Le traitement s'effectue via des requêtes HTTP POST asynchrones avec support du streaming de jetons pour un affichage fluide de la réponse à l'écran.

## 3. Code Source Applicatif (`app.py`)
Le fichier complet `app.py` est disponible dans ce dossier pour examen du jury.
