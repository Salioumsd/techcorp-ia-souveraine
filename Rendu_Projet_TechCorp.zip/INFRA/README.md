# 🛠️ Livrables INFRASTRUCTURE

## 1. Serveur d'Inférence Opérationnel
*   **Moteur local :** Docker + Ollama alimentant le modèle `Phi-3.5-Financial`.
*   **Statut :** Opérationnel sur `http://localhost:11434`.

## 2. Note Justificative des Choix Techniques
Le choix de s'appuyer sur une image Docker locale exécutant `Phi-3.5` (2.2 Go) est motivé par la stricte exigence de souveraineté des données financières de TechCorp. Aucune donnée ne quitte le réseau de l'entreprise, éliminant tout risque de fuite via des API tierces.

## 3. RoadMap de Scalabilité Industrielle (Triton)
Conformément au brief, le passage à l'échelle s'appuiera sur **NVIDIA Triton Inference Server** (tutoriels officiels : `github.com/triton-inference-server/tutorials`). Triton permettra :
1. La planification dynamique des lots (Dynamic Batching) pour maximiser le débit GPU.
2. Le service multi-modèle en parallèle (Financial local + adaptateurs R&D Médical).
3. L'optimisation des couches de poids via TensorRT-LLM.
